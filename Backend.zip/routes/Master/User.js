// Routes: userRoutes.js
const express = require('express');
const router = express.Router();
const User = require('../../Model/MasterSchema/UserSchema');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Middleware to get user by ID
async function getUserById(req, res, next) {
    let user;
    try {
        user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ message: 'User not found' });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
    res.user = user;
    next();
}
// Middleware to get user by email
async function getUserForLogin(req, res, next) {
    let user;


    try {

        if (req.body.employeeid) {
            user = await User.findOne({ employeeid: req.body.employeeid });
        } else if (req.body.email) {
            user = await User.findOne({ email: req.body.email });
        }

        if (!user) return res.status(404).json({ message: 'User Not found' });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
    res.user = user;
    next();
}



// Middleware to get user by employeeid
async function getUserByEmployeeId(req, res, next) {
    let user;
    try {
        user = await User.findOne({ employeeid: req.body.employeeid });
        if (!user) return res.status(404).json({ message: 'User not found' });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
    res.user = user;
    next();
}

// Middleware to check for duplicate email
async function checkDuplicateEmail(req, res, next) {
    let user;
    try {
        user = await User.findOne({ email: req.body.email });
        if (user && user._id != req.params.id) {
            return res.status(400).json({ message: 'Email already exists' });
        }
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
    next();
}

// GET all users with pagination
router.get('/user', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;
        const users = await User.find().skip(skip).limit(limit);
        const totalUsers = await User.countDocuments();
        const totalPages = Math.ceil(totalUsers / limit);
        res.json({ users, totalPages, totalUsers });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// GET a user by ID
router.get('/user/:id', getUserById, (req, res) => {
    res.json(res.user);
});

// GET all users without pagination
router.get('/alluser', async (req, res) => {
    try {
        const user = await User.find();
        console.log("Fetched user:", user);
        res.json(user);
    } catch (error) {
        console.error("Error fetching user:", error);
        res.status(500).json({ message: 'Server Error' });
    }
});



router.post('/user', checkDuplicateEmail, async (req, res) => {
    try {
        const {
            firstname,
            lastname,
            email,
            mobilenumber,
            address,
            city,
            state,
            country,
            zipCode,
            loginexpirydate,
            employeeid,
            department,
            password,
            manageremail,
            profileimage,
            deviceid,
            usertype,
            role,
            dealerInfo,
            skills,
            demographics
        } = req.body;

        // Validate required fields
        if (!password || typeof password !== 'string') {
            return res.status(400).json({ message: 'Password is required and must be a string' });
        }

        if (!email) {
            return res.status(400).json({ message: 'Email is required' });
        }

        // Hash password with proper error handling
        let hashedPassword;
        try {
            const salt = await bcrypt.genSalt(10);
            hashedPassword = await bcrypt.hash(password, salt);
        } catch (hashError) {
            console.error('Password hashing failed:', hashError);
            return res.status(500).json({ message: 'Password processing failed' });
        }

        // Prepare user data with null checks
        const userData = {
            firstname: firstname || '',
            lastname: lastname || '',
            email: email || '',
            mobilenumber: mobilenumber || '',
            status: "Active",
            location: address || '',
            city: city || '',
            state: state || '',
            country: country || '',
            zipCode: zipCode || '',
            loginexpirydate: loginexpirydate ? new Date(loginexpirydate) : null,
            employeeid: employeeid || '',
            department: department || '',
            password: hashedPassword,
            manageremail: manageremail || '',
            profileimage: profileimage || '',
            deviceid: deviceid || '',
            deviceregistereddate: new Date(),
            usertype: usertype || 'skanray',
            skills: skills || [],
            demographics: demographics || [],
            modifiedAt: new Date(),
            createdAt: new Date()
        };

        // Add role/dealer info based on user type
        if (usertype === 'skanray') {
            userData.role = {
                roleName: role?.roleName || '',
                roleId: role?.roleId || ''
            };
        } else if (usertype === 'dealer') {
            userData.dealerInfo = {
                dealerName: dealerInfo?.dealerName || '',
                dealerId: dealerInfo?.dealerId || ''
            };
        }

        // For backward compatibility
        const branchData = demographics?.find(d => d.type === 'branch');
        if (branchData) {
            userData.branch = branchData.values.map(v => v.name) || [];
        }

        const newUser = new User(userData);
        const savedUser = await newUser.save();

        res.status(201).json(savedUser);
    } catch (err) {
        console.error("Error creating user:", err);
        res.status(400).json({
            message: err.message,
            errorDetails: process.env.NODE_ENV === 'development' ? err.stack : undefined
        });
    }
});
// LOGIN route
router.post('/login', getUserForLogin, async (req, res) => {


    try {
        const user = res.user;
        const isMatch = await bcrypt.compare(req.body.password, user.password);
        if (!isMatch) return res.status(400).json({ message: 'Invalid password' });
        console.log("ismatch", isMatch)
        const currentDeviceId = req.body.deviceid;

        if (user.deviceid && user.deviceid !== currentDeviceId) {
            return res.status(403).json({
                message: 'User is already logged in on another device',
                errorCode: 'DEVICE_MISMATCH'
            });
        }
        // Update device information
        user.deviceid = currentDeviceId;
        user.deviceregistereddate = new Date();
        await user.save();

        const token = jwt.sign(
            { id: user._id, email: user.email },
            "myservice-secret"
        );

        res.json({
            token,
            user: {
                id: res.user._id,
                firstname: res.user.firstname,
                lastname: res.user.lastname,
                email: res.user.email,
                mobilenumber: res.user.mobilenumber,
                status: res.user.status,
                branch: res.user.branch,
                loginexpirydate: res.user.loginexpirydate,
                employeeid: res.user.employeeid,
                country: res.user.country,
                state: res.user.state,
                city: res.user.city,
                department: res.user.department,
                skills: res.user.skills,
                profileimage: res.user.profileimage,
                deviceid: res.user.deviceid,
                usertype: res.user.usertype,
                role: res.user.role,
                dealerInfo: res.user.dealerInfo,
                location: res.user.location
            }
        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});
router.post('/remove-device', async (req, res) => {
    try {
        const { userId } = req.body; // frontend se userId ayega

        if (!userId) {
            return res.status(400).json({ message: 'User ID is required' });
        }

        // Find user and clear device information
        const updatedUser = await User.findByIdAndUpdate(
            userId,
            {
                $set: {
                    deviceid: null,
                    deviceregistereddate: null
                }
            },
            { new: true } // Return updated document
        );

        if (!updatedUser) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({
            message: 'Device ID cleared successfully',
            user: updatedUser
        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});



// UPDATE a user
router.put('/user/:id', getUserById, checkDuplicateEmail, async (req, res) => {
    if (req.body.firstname != null) res.user.firstname = req.body.firstname;
    if (req.body.lastname != null) res.user.lastname = req.body.lastname;
    if (req.body.email != null) res.user.email = req.body.email;
    if (req.body.mobilenumber != null) res.user.mobilenumber = req.body.mobilenumber;
    if (req.body.status != null) res.user.status = req.body.status;
    if (req.body.branch != null) res.user.branch = req.body.branch; // expect an array
    if (req.body.loginexpirydate != null) res.user.loginexpirydate = req.body.loginexpirydate;
    if (req.body.employeeid != null) res.user.employeeid = req.body.employeeid;
    if (req.body.country != null) res.user.country = req.body.country;
    if (req.body.state != null) res.user.state = req.body.state;
    if (req.body.city != null) res.user.city = req.body.city;
    if (req.body.department != null) res.user.department = req.body.department;
    if (req.body.manageremail != null) res.user.manageremail = req.body.manageremail;
    if (req.body.skills != null) res.user.skills = req.body.skills;
    if (req.body.profileimage != null) res.user.profileimage = req.body.profileimage;
    if (req.body.deviceid != null) res.user.deviceid = req.body.deviceid;
    if (req.body.usertype != null) res.user.usertype = req.body.usertype;
    if (req.body.roleName != null) {
        res.user.role = {
            roleName: req.body.roleName,
            roleId: req.body.roleId
        };
    }
    if (req.body.dealerName != null) {
        res.user.dealerInfo = {
            dealerName: req.body.dealerName,
            dealerId: req.body.dealerId
        };
    }
    if (req.body.location != null) res.user.location = req.body.location; // expect an array

    try {
        const updatedUser = await res.user.save();
        res.json(updatedUser);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// DELETE a user
router.delete('/user/:id', async (req, res) => {
    try {
        const userDeleted = await User.deleteOne({ _id: req.params.id });
        if (userDeleted.deletedCount === 0) {
            return res.status(404).json({ message: "User Not Found" });
        }
        res.json({ message: 'Deleted User' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// SEARCH route
router.get('/search', async (req, res) => {
    try {
        const { q } = req.query;
        if (!q) return res.status(400).json({ message: 'Query parameter is required' });

        const query = {
            $or: [
                { firstname: { $regex: q, $options: 'i' } },
                { lastname: { $regex: q, $options: 'i' } },
                { email: { $regex: q, $options: 'i' } },
                { mobilenumber: { $regex: q, $options: 'i' } },
                { status: { $regex: q, $options: 'i' } },
                { branch: { $regex: q, $options: 'i' } },
                { country: { $regex: q, $options: 'i' } },
                { state: { $regex: q, $options: 'i' } },
                { city: { $regex: q, $options: 'i' } },
                { department: { $regex: q, $options: 'i' } },
                { manageremail: { $regex: q, $options: 'i' } },
                { skills: { $regex: q, $options: 'i' } },
                { usertype: { $regex: q, $options: 'i' } }
            ]
        };

        const users = await User.find(query);
        res.json(users);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
