const mongoose = require('mongoose');

const PMSchema = new mongoose.Schema(
  {
    pmType: {
      type: String,
      required: true,
    },
    pmNumber: {
      type: String,
      unique: true,
      sparse: true, // Add this option so that missing or null values are not indexed.
    },
    materialDescription: {
      type: String,
    },
    documentnumber: {
      type: String,
    },
    serialNumber: {
      type: String,
      required: true,
    },
    customerCode: {
      type: String,
    },
    region: {
      type: String,
    },

    city: {
      type: String,
    },
    pmDueMonth: {
      type: String,
      match: /^(0[1-9]|1[0-2])\/\d{4}$/, // Format MM/YYYY
    },
    pmDoneDate: {
      type: String,
      match: /^\d{2}\/\d{2}\/\d{4}$/, // Format DD/MM/YYYY
    },
    pmVendorCode: {
      type: String,
    },
    pmEngineerCode: {
      type: String,
    },
    pmStatus: {
      type: String,
      enum: ["Completed", "Due", "Overdue", "Lapse"],
    },
    partNumber: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("PM", PMSchema);
